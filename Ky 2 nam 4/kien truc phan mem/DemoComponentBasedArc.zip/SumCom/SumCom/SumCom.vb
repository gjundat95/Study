﻿Public Class SumCom
    Public Function Sum(a As Integer, b As Integer) As Integer

        Return a + b

    End Function
    Public Function Minus(a As Integer, b As Integer) As Integer

        Return a - b

    End Function


End Class
